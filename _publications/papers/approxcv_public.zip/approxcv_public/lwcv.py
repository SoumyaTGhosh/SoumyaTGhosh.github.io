"""
Leave Within Structure Out Cross-Validation (LWCV)
"""
import autograd
import autograd.numpy as np
import matplotlib.pyplot as plt
from gen_synthetic_data import genSyntheticDataset
from hidden_markov_model import HMM


def compute_hessian(model):
    eval_hess = autograd.hessian(model.weighted_loss, argnum=0)
    H = eval_hess(model.params_one, model.weights_one)
    return H


def compute_Jmatrix(model):
    eval_d2l_dParams_dWeights = autograd.jacobian(autograd.jacobian(model.weighted_loss, argnum=0), argnum=1)
    J = eval_d2l_dParams_dWeights(model.params_one, model.weights_one)
    return J


def compute_HinvJ(model):
    H = compute_hessian(model)
    J = compute_Jmatrix(model)
    HinvJ = -np.linalg.solve(H, J)
    return HinvJ


def LWCV(model, o):
    """
    Leave within structure cross-validation. N=1.
    :param model: Pre-trained model
    :param o: Indices of sites to be dropped
    :return: Approximated parameter
    """
    H = compute_hessian(model)
    J = compute_Jmatrix(model)
    HinvJ = -np.linalg.solve(H, J)
    weights = np.ones([model.T])
    weights[o] = 0  # dropped sites
    params_acv = model.params_one + HinvJ.dot(weights - 1)
    return params_acv


if __name__ == '__main__':
    D = 2
    K = 2
    T = 1500
    pct_to_drop = 5
    X, zs, A, pi0, mus = genSyntheticDataset(K=K, T=T, N=1, D=D)

    config_dict = {'K': K, 'precision': None}
    model = HMM(X, config_dict)
    # MAP fit
    opt_params = model.fit(model.weights_one, init_params=None, num_random_restarts=1, verbose=True, maxiter=None)
    model.params_one = opt_params.copy()
    # i.i.d LWCV
    o = np.random.choice(T, size=np.int(pct_to_drop / 100. * T), replace=False) + 1
    params_acv = LWCV(model, o)
    # compare against exact CV
    weights = np.ones([model.T])
    weights[o] = 0
    approx_cv_loss = model.loss_at_missing_timesteps(weights, params=params_acv)
    params_cv = model.fit(weights, init_params=model.params_one)  # exact cv with warm start
    exact_cv_loss = model.loss_at_missing_timesteps(weights, params=params_cv)
    plt.plot(exact_cv_loss, approx_cv_loss, 'ro', ms=10, alpha=0.5)
    plt.plot([0, 5], [0, 5], 'k--', lw=3)
    plt.show()

    # from IPython import embed;
    # np.set_printoptions(linewidth=150);
    # embed()


